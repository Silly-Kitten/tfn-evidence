			function BiTfunction() {
				document.getElementById("B1tmyDropdown").classList.toggle("show");
			}
			window.onclick = function(e) {
				if (!e.target.matches('.B1tdropbtn')) {
					var B1tmyDropdown = document.getElementById("B1tmyDropdown");
						if (B1tmyDropdown.classList.contains('show')) {
							B1tmyDropdown.classList.remove('show');
					}
				}
			}
			function myfunction() {
				document.getElementById("myDropdown").classList.toggle("show");
			}
			window.onclick = function(e) {
				if (!e.target.matches('.dropbtn')) {
					var myDropdown = document.getElementById("myDropdown");
						if (myDropdown.classList.contains('show')) {
							myDropdown.classList.remove('show');
					}
				}
			}